import sys
import time
from enum import Enum

class Direction(Enum):
	north = 0
	east = 1
	south = 2
	west = 3

class Tile(Enum):
	empty = 0
	myCar = 1
	opponentCar = 2
	takenByMe = 3
	takenByOpponent = 4

debug = open("debug.log", "w")
def printOut(string):
	debug.write(str(string)+"\n")

class Networker:
	def __init__(self):
		self.playerIndex = int(sys.stdin.readline().strip())

	def deserializeMap(self, mapString):
		tiles = [int(tile) for tile in mapString.split(" ")]
		if self.playerIndex == 2: tiles = [tile-1 if tile == 2 or tile == 4 else (tile+1 if tile == 1 or tile == 3 else tile) for tile in tiles]
		map = [tiles[a*16 : (a+1)*16] for a in range(16)]
		return map

	def getMap(self):
		message = sys.stdin.readline().strip()
		if message == "KILL": sys.exit()
		return self.deserializeMap(message)

	def sendMove(self, move):
		sys.stdout.write(str(move) + "\n")
		sys.stdout.flush()